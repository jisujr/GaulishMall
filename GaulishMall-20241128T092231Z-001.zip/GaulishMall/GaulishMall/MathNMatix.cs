﻿namespace GaulishMall;

public class MathNMatix
{
    // Compress fun 
    public static string Compress(string uncompressed)
    {
        if (uncompressed.Length == 0) // ethe main if kita 
            
            return ""; // fir rt it  kita 
            

        string pt = ""; int lv = 1; // fir string kita 

        for (int a = 1; a < uncompressed.Length; a++) // fir main for kita 
        {
            if (uncompressed[a] == uncompressed[a - 1] && lv < 9) // fir main if kita 
            {
                lv++;
            }
            else
            {
                pt += lv.ToString() + uncompressed[a - 1];lv = 1; // fir tostirng kita 
            }
        }

        pt += lv.ToString() + uncompressed[uncompressed.Length - 1]; // ethe main tostring kita 

        return pt; // rt pt kita 
    }
    //Uncompress fun 
    
    public static string Uncompress(string compressed)
    {
        if (compressed.Length == 0)
        {
            return ""; // ethe main rt it kita 
        }

        string a = ""; int st = 0;

        while (st < compressed.Length) // ethe while kita 
        {
            if (st + 1 < compressed.Length && compressed[st] >= '1' && compressed[st] <= '9') // Ette main if condition kita 
            {
                int t = Convert.ToInt32(compressed[st].ToString()); // Ethe main int t kita 
                if (t < 1 || t > 9)
                {
                    throw new ArgumentException(""); // ethe trw arg kita 
                }

                if (st + 1 < compressed.Length && (compressed[st + 1] < '0' || compressed[st + 1] > '9')) // Fir main if condition kita 
                {
                    char lst = compressed[st + 1]; a += new string(lst, t); st += 2;  // fir char nu define kita 
                }
                else
                {
                    throw new ArgumentException(""); // ethe trw arg kita 
                }
            }
            else
            {
                throw new ArgumentException(""); // ethe trw arg kita 
            }
        }

        return a; // ethe main rt a kita 
    }

    // Matrix Multiplication fun veh
    public static int[,] MatrixMult(int[,] mat1, int[,] mat2)
    {
        int a = mat1.GetLength(0);  int b = mat1.GetLength(1);  int x = mat2.GetLength(0);   int y = mat2.GetLength(1);

        if (b != x) // ethe main b kita 
        {
            throw new ArgumentException("error"); // fir thw arg kita 
        }

        int[,] love = new int[a, y]; // ethe laun int kita 

        for (int t = 0; t < a; t++) // ethe main for kita 
        {
            for (int p = 0; p < y; p++) // ethe vi for kita 
            {
                love[t, p] = 0;

                for (int l = 0; l < b; l++) // fir for kita ethe 
                {
                    love[t, p] += mat1[t, l] * mat2[l, p];
                }
            }
        }

        return love; // rt it love kita 
    }


}