﻿namespace GaulishMall;

public class Shop
{
    //CreateShops fun
    public static string[] CreateShops(string shop1, string shop2, string shop3, string shop4)
    {
        return new string[] { shop1, shop2, shop3, shop4 }; // rt it new str 
    }

    //SwapShops fun

    public static void SwapShops(string[] shop1, string[] shop2, int i, int j)
    {
        if (i < 1 || i > 4 || j < 1 || j > 4) // ethe main if kita fir main sare table vich test kite 
        {
            throw new ArgumentException(" Error on SwapShops"); // thw exp kita 
        }

        int a = i - 1;
        int b = j - 1; // ethe main int kita 

        (shop1[a], shop2[b]) =
            (shop2[b], shop1[a]); // ethe main dono shops nu equal kita 
    }

    // Reverse fun
    public static void Reverse(char[] name)
    {
        int m = 0, s = name.Length - 1;
        while (m < s) // ethe while kita 
        { (name[m], name[s]) = (name[s], name[m]);
            m++; s--; }  // fir sare test kite 

    }
    // WherelsCeasar fun
    
    public static int[] WhereIsCaesar(string owner, string[] register)
    {
        int z = 0;
        foreach (var s in register)
        {
            if (s == owner) z++; // ethe main fir if kita 
        }

        int[] lv = new int[z]; // eht main nw int paha 
        int st = 0;
        for (int j = 0; j < register.Length; j++) // ethe main bcl for kiti 
        {
            if (register[j] == owner)
            {
                lv[st] = j;
                st++;
            }
        }

        return lv; // rt it
    }
    
    //bubblesort fun
    
    public static void BubbleSort(int[] keys)
    { for (int a = 0; a < keys.Length - 1; a++) // ethe main bcl for kita 
        
        for (int c = 0; c < keys.Length - 1 - a; c++) // ethe vi fir int nal kita 
            
            if (keys[c] > keys[c + 1]) (keys[c], keys[c + 1]) = (keys[c + 1], keys[c]); // ethe main keys use kitiyan
    }
    
    // Item selection fun
    public static int[] Selection(int[] array, int budget)
    {
        if (array == null || budget <= 0)
            throw new ArgumentException("error");// ethe arm kita 

        for (int s = 0; s < array.Length; s++)  // ethe for kita 
        {
            if (array[s] <= 0)
                throw new ArgumentException("error"); // ethe arm kita 
        }

        int[] mv = Ace(array);  // array ਨੂੰ decreasing order ਵਿੱਚ sort ਕਰਦਾ ਹੈ।
        int[] lv = new int[array.Length];
        int t = 0; int ma = 0;

        for (int s = 0; s < mv.Length; s++)
        {
            if (ma + mv[s] <= budget)  // ਜੇ current item add ਕਰਨ ਨਾਲ budget exceed ਨਹੀਂ ਹੁੰਦਾ:
            {
                lv[t] = mv[s];
                ma += mv[s];
                t++;
            }
        }

        int[] jr = new int[t];
        for (int s = 0; s < t; s++)
        {
            jr[s] = lv[s];
        }

        return jr; // ethe rt it kita 
    }

    private static int[] Ace(int[] array)
    {
        int[] mv = new int[array.Length]; // new int kita ethe main 
        for (int s = 0; s < array.Length; s++)
        {
            mv[s] = array[s];
        }

        for (int s = 0; s < mv.Length - 1; s++) // ethe vi for kita 
        {
            for (int z = s + 1; z < mv.Length; z++) // ethe for kita 
            {
                if (mv[s] < mv[z])
                {
                    int mo = mv[s]; mv[s] = mv[z]; mv[z] = mo;
                }
            }
        }

        return mv; // ethe vi rt mv kita 
    }
    
    //binarix fun 
    public static int Binarix(int[] array, int x)
    {
        int a = 0;  int b = array.Length - 1;

        while (a <= b)
        {
            int op = a + (b - a) / 2;  // ਮੱਧ ਦਾ ਇੰਡੈਕਸ ਕੈਲਕੁਲੇਟ ਕਰੋ
            if (array[op] == x)
            
                return op;  // rt it kita 
            
            else if (array[op] < x)
            
                a = op + 1;  // ਜੇ x ਮੱਧ ਤੋਂ ਵੱਡਾ ਹੈ ਤਾਂ ਸੱਜੇ ਹਿੱਸੇ ਵਿੱਚ ਖੋਜ ਕਰੋ
            
            else  b = op - 1;  // ਜੇ x ਮੱਧ ਤੋਂ ਛੋਟਾ ਹੈ ਤਾਂ ਖੱਬੇ ਹਿੱਸੇ ਵਿੱਚ ਖੋਜ ਕਰੋ
            
        }
        return a;  // rt it kita 
    }

    
    


}
