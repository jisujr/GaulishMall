﻿namespace GaulishMall;

public class Sudokus
{
    // InLine Fun 
    
    public static bool InLine(int[,] grid, int line, int digit)
    {
        for (int lst = 0; lst < 9; lst++) // ethe for kita 
        {
            if (grid[line, lst] == digit)
                return true;  // ethe rt true kita 
        
        }
        return false; // rt it false kita 
    }
    
    //Incol fun 
    public static bool InCol(int[,] grid, int col, int digit)
    {
        for (int mvt = 0; mvt < 9; mvt++) // ethe for function kiti 
        {
            if (grid[mvt, col] == digit)
                return true; // ethe rt true kita 
        
        }
        return false; // rt it false kita 
    }
    
    // Inbox fun 
    
    public static bool InBox(int[,] grid, int box, int digit)
    {
        int lav = (box / 3) * 3; int am = (box % 3) * 3; // ethe int kita 

        for (int a = lav; a < lav + 3; a++)
        {
            for (int b = am ; b < am + 3; b++) // ethe for kkita 
            {
                if (grid[a, b] == digit) // ethe if kita 
                    return true; // ethe rt trus kita 
                
            }
        }

        return false; // ethe rt false kita 
    }
    
    // Solver fun 
    public static bool Solver(int[,] grid)
    {
        for (int mst = 0; mst < 9; mst++) // ethe for kita 
        {
            for (int li = 0; li < 9; li++) // ethe for kita 
            {
                if (grid[mst, li] == 0) // ethe if kita 
                {
                    for (int t = 1; t <= 9; t++)
                    {
                        if (!InLine(grid, mst, t) && !InCol(grid, li, t) && !InBox(grid, (mst / 3) * 3 + (li / 3), t))
                        {
                            grid[mst, li] = t; // ethe grid nu equal kita 

                            if (Solver(grid)) 
                                return true; // Si la récursion réussit, retourner vrai

                            grid[mst, li] = 0; // ethe vi grid nu equal kita 
                        }
                    }
                    return false; // ethe rt false kita 
                }
            }
        }
        return true; // ethe rt true kita 
    }

    
    



}