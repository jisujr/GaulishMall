﻿namespace GaulishMall;

public class Matrix
{
    // CountItems fun 
    
    public static int CountItems(int[,] shops, int price)
    {
        int t = 0; // ethe main int ktia 

        int w = shops.GetLength(0);  int s = shops.GetLength(1);

        for (int a = 0; a < w; a++) 
        {
            for (int b = 0; b < s; b++) // ethe main for kita 
            {
                if (shops[a, b] == price)  t++;// ethe main if kita 
            }
        } return t; // ethe main rt it kita 
    }
    
    //FindItems fun 
    
    public static int[,] FindItems(int[,] shops, int price)
    {
        int p = shops.GetLength(0); int o = shops.GetLength(1); // ethe main int kita 
        int st = 0;

        for (int a = 0; a < p; a++) // ethe vi for kita 
        {
            for (int b = 0; b < o; b++) // ethe vi for kita 
            {
                if (shops[a, b] == price) st++; // if condition to count matches
            }
        }

        if (st == 0) return new int[0, 2]; // ethe vi for kita (correction: dimensions fixed)

        int[,] t = new int[st, 2]; int y = 0; // ethe int kita 

        for (int a = 0; a < p; a++) // ethe vi for kita 
        {
            for (int b = 0; b < o; b++) // ethe main for kita 
            {
                if (shops[a, b] == price) // ethe main if kita 
                {
                    t[y, 0] = a; t[y, 1] = b; y++; // ethe main t kita 
                }
            }
        }

        return t; // rt it t 
    }

    //Rotateshops fun 
    
    public static int[,] RotateShops(int[,] shops)
    {
        int w = shops.GetLength(0); int lv = shops.GetLength(1); // ethe main int kita et teh get.lenth use kita 

        int[,] mt = new int[lv, w];

        for (int a = 0; a < w; a++) // ethe main for kita 
        {
            for (int b = 0; b < lv; b++) 
            {
                mt[b, a] = shops[a, b]; // ethe main mt kita 
            }
        }

        return mt; // ethe main mt kita 
    }
    
    // CountJagged fun
    public static int CountJagged(int[][] shops, int price)
    {
        int s = 0; for (int a = 0; a < shops.Length; a++) //ethe main for lita  teh int kita 
        {
            for (int b = 0; b < shops[a].Length; b++) // ethe main for kita 
            
                if (shops[a][b] == price) s++; // ethe main if kita 
                
            
        }

        return s; // ethe main rt s kita 
    }
    
    // Trim array fun 
    
    public static string[][] Trim(string[][] arr, string[] forbidden)
    {
        string[][] t = new string[arr.Length][];

        for (int a = 0; a < arr.Length; a++) // ethe main for kita 
        {int mv = 0; for (int b = 0; b < arr[a].Length; b++) // ethe main int kita 
            {
                if (!LV(arr[a][b], forbidden)) mv++;
                    
            }
            string[] stl = new string[mv];  int pv = 0;

            for (int b = 0; b < arr[a].Length; b++)
            {
                if (!LV(arr[a][b], forbidden))  stl[pv++] = arr[a][b]; // ethe main for kita 
                    
            }

            t[a] = stl;
        }

        return t; // ethe main rt it kita 
    }

    private static bool   LV(string shop, string[] forbidden)
    {

        for (int a = 0; a < forbidden.Length; a++) // ethe main fir for kita 
        {
            if (shop == forbidden[a]) // ethe main if kita 
                
                return true; // rt it true kita 
                
        }

        return false; // rt it false kita 
    }

    // Second-largest fun 

    public static int SecondLargest(int[][] shops)
    {
            
        if (shops.Length == 0 || shops[0].Length < 2)
        {
            throw new ArgumentException("error"); // ethe mai thrw  arg kita 
        }

            
        int gt = int.MinValue; int mk = int.MinValue; bool pk = false; // ethe main int kita 

            
        for (int i = 0; i < shops.Length; i++) // ethe main for kita
        {
            for (int j = 0; j < shops[i].Length; j++) // ethe vi main for kita 
            {
                int t = shops[i][j];

                    
                if (t > gt)
                {
                    mk = gt; gt = t;  pk = true; // ethe main mk teh hor buhat kujh kita 
                }
                else if (t > mk && t < gt)
                {
                    mk = t; pk = true; // ethe main int kita 
                }
            }
        }
        if (!pk || mk == int.MinValue)
        {
            throw new ArgumentException("error"); // ethe ethe thrw kitaz 
        }

        return mk; // rt it kita 
    }
    
    //Pascal fun 
    
    public static int[][] Pascal(uint n)
    {
        int[][] bit = new int[n + 1][];// ਇੱਥੇ ਜੈਗਡ ਐਰੇ ਦੀ ਘੋਸ਼ਣਾ ਕੀਤੀ ਗਈ ਹੈ ਜੋ ਪੈਸਕਲ ਟ੍ਰਾਇਐਂਗਲ ਨੂੰ ਸੰਭਾਲੇਗਾ

        
        for (int l = 0; l <= n; l++) 
        {
            bit[l] = new int[l + 1]; // ਹਰ ਪੰਕਤੀ ਲਈ ਨਵਾਂ ਐਰੇ ਬਣਾਇਆ ਜਾ ਰਿਹਾ ਹੈ

            for (int a = 0; a <= l; a++)  // ਇੱਥੇ ਹਰ ਕਾਲਮ ਨੂੰ ਪ੍ਰੋਸੈੱਸ ਕਰ ਰਿਹਾ ਹੈ
            {
                
                if (a == 0 || a == l) // ਜੇ ਕਾਲਮ 0 ਜਾਂ ਪੰਕਤੀ ਦੀ ਆਖਰੀ ਕਾਲਮ ਹੋਵੇ, ਤਾਂ ਮੁੱਲ 1 ਸੈੱਟ ਕਰੋ
                {
                    bit[l][a] = 1;
                }
                else
                {
                    bit[l][a] = bit[l - 1][l - 1] + bit[l - 1][a];// ਪਿਛਲੀ ਪੰਕਤੀਆਂ ਦੇ ਅੰਕੜਿਆਂ ਨੂੰ ਜੋੜ ਕੇ ਨਵਾਂ ਅੰਕੜਾ ਪ੍ਰਾਪਤ ਕਰੋ
                }
            }
        }
        return bit; // rt it bit kita main 
    }

    
}